import { Request, Response } from "express";
import { extractTextFromImage } from "./ocr.service";

export async function extractOCR(req: Request, res: Response) {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No file uploaded",
      });
    }

    const text = await extractTextFromImage(req.file.buffer);

    res.json({
      success: true,
      text,
    });
  } catch (err) {
    console.error("OCR error:", err);
    res.status(500).json({
      success: false,
      message: "OCR processing failed",
    });
  }
}
