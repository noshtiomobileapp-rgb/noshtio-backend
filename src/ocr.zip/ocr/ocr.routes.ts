import { Router } from "express";
import multer from "multer";
import { extractOCR } from "./ocr.controller";

console.log("✅ OCR ROUTES FILE LOADED");

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

/**
 * Health check
 */
router.get("/ping", (_req, res) => {
  res.send("OCR OK");
});

/**
 * OCR extraction
 * POST /api/ocr/extract
 */
router.post("/extract", upload.single("file"), extractOCR);

export default router;
