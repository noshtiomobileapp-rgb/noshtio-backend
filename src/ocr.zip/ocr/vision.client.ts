import vision from "@google-cloud/vision";
import path from "path";

const keyPath = path.resolve(
  __dirname,
  "../config/google-vision-key.json"
);

export const visionClient = new vision.ImageAnnotatorClient({
  keyFilename: keyPath,
});
