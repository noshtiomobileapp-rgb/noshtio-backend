import express from "express";
import cors, { CorsOptions } from "cors";
import morgan from "morgan";

/* ============================================================
   FORCE SIDE EFFECT IMPORTS
============================================================ */
import ocrRoutes from "./modules/ocr";

/* ============================================================
   ROUTES
============================================================ */
import authRoutes from "./modules/auth/auth.routes";
import protectedRoutes from "./modules/example/protected.routes";
import menuRoutes from "./modules/menu/menu.routes";
import orderRoutes from "./modules/orders/order.routes";
import vendorOrdersRoutes from "./routes/vendorOrders.routes";
import menuUploadRoutes from "./routes/menu.upload.routes";
import vendorAnalyticsRoutes from "./modules/menu/analytics/analytics.routes";

/* ============================================================
   INIT
============================================================ */
const app = express();

/* ============================================================
   CORS — PRODUCTION SAFE (COOKIE + AUTH HEADER)
============================================================ */
const ALLOWED_ORIGINS = [
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  "https://www.noshtio.com",
  "https://noshtio.com",
];

const corsOptions: CorsOptions = {
  origin: (origin, cb) => {
    // Allow server-to-server & preflight without origin
    if (!origin) return cb(null, true);

    if (ALLOWED_ORIGINS.includes(origin)) {
      return cb(null, true);
    }

    // IMPORTANT: never throw here — silently block
    return cb(null, false);
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: [
    "Content-Type",
    "Authorization",
    "X-Requested-With",
  ],
};

app.use(cors(corsOptions));
app.options("*", cors(corsOptions));

/* ============================================================
   GLOBAL MIDDLEWARE
============================================================ */
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));

/* ============================================================
   ROUTES
============================================================ */
app.use("/api/ocr", ocrRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/example", protectedRoutes);

app.use("/api/vendor/menu", menuRoutes);
app.use("/api/vendor/menu", menuUploadRoutes);
app.use("/api/vendor/analytics", vendorAnalyticsRoutes);
app.use("/api/vendor", vendorOrdersRoutes);

app.use("/api/customer/orders", orderRoutes);

/* ============================================================
   HEALTH CHECK
============================================================ */
app.get("/", (_req, res) => {
  res.json({
    status: "OK",
    message: "Server is running",
  });
});

export default app;
