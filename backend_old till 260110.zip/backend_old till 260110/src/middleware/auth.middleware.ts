import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

export interface AuthenticatedRequest extends Request {
  user?: any;
}

// Strict auth — requires token
export const authMiddleware = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const header = req.headers.authorization;
  const cookieToken = req.cookies?.auth_token;

  const token = header?.startsWith("Bearer ")
    ? header.split(" ")[1]
    : cookieToken;

  if (!token) {
    return res.status(401).json({ success: false, message: "Missing token" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ success: false, message: "Invalid token" });
  }
};

// Optional auth — allows anonymous but attaches user if token is valid
export const optionalAuth = (req: AuthenticatedRequest, _res: Response, next: NextFunction) => {
  const header = req.headers.authorization;
  const cookieToken = req.cookies?.auth_token;

  const token = header?.startsWith("Bearer ")
    ? header.split(" ")[1]
    : cookieToken;

  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
      req.user = decoded;
    } catch {
      // ignore invalid token, continue as guest
    }
  }

  next();
};

// Default export for legacy imports
export default authMiddleware;
