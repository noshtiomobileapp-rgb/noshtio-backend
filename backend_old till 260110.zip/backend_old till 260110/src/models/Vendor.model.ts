import mongoose, { Schema, Document, Types } from "mongoose";

/* ============================================================
   | Vendor Document Interface
   ============================================================ */
export interface VendorDocument extends Document {
  name: string;
  email: string;
  password: string;
  role: "vendor";
  user: Types.ObjectId; // Reference to User model
}

/* ============================================================
   | Vendor Schema
   ============================================================ */
const VendorSchema = new Schema<VendorDocument>(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true },
    role: { type: String, enum: ["vendor"], default: "vendor" },

    // 👇 Reference to the authenticated user (User model)
    user: { type: Schema.Types.ObjectId, ref: "User", required: true }
  },
  { timestamps: true }
);

/* ============================================================
   | Vendor Model Export
   ============================================================ */
export default mongoose.model<VendorDocument>("Vendor", VendorSchema);
